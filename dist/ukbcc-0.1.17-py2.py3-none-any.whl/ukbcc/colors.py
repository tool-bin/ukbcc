terminal = {
    "default": '\033[0m',
    "bold": '\033[1m',
    "blue": '\033[94m',
    "green": '\033[92m',
    "orange": '\033[93m',
    "red": '\033[91m'
}
